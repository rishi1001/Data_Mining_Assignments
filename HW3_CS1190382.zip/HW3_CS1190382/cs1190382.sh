git clone https://github.com/rishi1001/Data_Mining_Assignments.git
cd Data_Mining_Assignments
unzip HW3_CS1190382.zip
cd HW3_CS1190382
