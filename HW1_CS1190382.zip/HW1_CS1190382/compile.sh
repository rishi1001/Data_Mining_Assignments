rm -f fpt apriori
make apriori
make fptree
