cd Q2
g++ -std=c++11 -O3 query.cpp -I vf3lib/include -o query
cd ..
./Q2/query