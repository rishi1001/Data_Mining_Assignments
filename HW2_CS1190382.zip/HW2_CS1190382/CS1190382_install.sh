git clone https://github.com/rishi1001/Data_Mining_Assignments.git
cd Data_Mining_Assignments
unzip HW2_CS1190382.zip
cd HW2_CS1190382
module load apps/anaconda/3
module load compiler/gcc/9.1.0
